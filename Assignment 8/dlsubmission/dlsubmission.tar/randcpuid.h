extern _Bool rdrand_supported (void);
static struct cpuid
cpuid (unsigned int leaf, unsigned int subleaf);
